# TCP_IM
An application-level protocol use TCP, with a server program in serv/.

```make``` to create static link library libim.a and server program.

More information at docs/Protocol.md.
